/*
 * IJarBrowserController.java
 *
 * Created on October 27, 2007, 9:36 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package com.swayam.utils;

import java.awt.event.MouseListener;

/**
 *
 * @author paawak
 */
public interface IJarBrowserController {
    
    MouseListener getAddToPathListener();
    
    MouseListener getSearchListener();
    
}
