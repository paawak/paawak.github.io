/*
 * JarBrowserView.java
 *
 * Created on October 27, 2007, 9:30 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package com.swayam.utils;

import java.io.File;
import java.util.List;
import javax.swing.JFrame;
import javax.swing.tree.TreeNode;

/**
 *
 * @author paawak
 */
public interface JarBrowserView {
    
    JFrame getFrame();
    
    String getElementToSearch();
    
    void addToSearchPath(List<File> files);
    
    void setResults(TreeNode results);
    
    List<File> getPathToSearch();
    
}
