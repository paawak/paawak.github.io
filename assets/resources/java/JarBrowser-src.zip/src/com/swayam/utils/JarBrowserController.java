/*
 * JarBrowserController.java
 *
 * Created on October 27, 2007, 9:38 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package com.swayam.utils;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Enumeration;
import java.util.List;
import java.util.jar.JarEntry;
import java.util.jar.JarFile;
import javax.swing.JFileChooser;
import javax.swing.filechooser.FileFilter;
import javax.swing.tree.DefaultMutableTreeNode;

/**
 *
 * @author paawak
 */
public class JarBrowserController implements IJarBrowserController {
    
    private final JFileChooser fileChooser;
    
    private final MouseListener addToPathListener;
    
    private final MouseListener doSearchListener;
    
    private final JarBrowserView view;
    
    /** Creates a new instance of JarBrowserController */
    public JarBrowserController(JarBrowserView viewImpl) {
        
        view = viewImpl;
        
        fileChooser = new JFileChooser();
        
        fileChooser.setMultiSelectionEnabled(true);
        
        fileChooser.setFileFilter(new FileFilter() {
            
            public boolean accept(File f) {
                String name = f.getName();
                return f.isDirectory()
                    || name.endsWith(".jar")
                    || name.endsWith(".zip");
            }
            
            public String getDescription() {
                return "*.jar, *.zip";
            }
            
        });
        
        addToPathListener = new MouseAdapter() {
            
            public void mouseReleased(MouseEvent e) {
                 int choice = fileChooser.showDialog(view.getFrame(), "Select path");
                 
                 if (choice == JFileChooser.APPROVE_OPTION) {
                     File[] files = fileChooser.getSelectedFiles();
                     
                     view.addToSearchPath(Arrays.asList(files));           
                     
                 }
                 
            }
            
            
        };
        
        doSearchListener = new MouseAdapter() {
            
            public void mouseReleased(MouseEvent e) {
                     String searchEle = replaceDotsBySlashes(view.getElementToSearch());
                     
                     DefaultMutableTreeNode treeNode = new DefaultMutableTreeNode("<html><font color='green'>Search Results</font></html>");
                     
                     for (File jarFile : view.getPathToSearch()) {
                         String filePath = jarFile.getAbsolutePath();

                         List<String> matches = getElementMatches(searchEle, jarFile);
                         
                         if (matches.size() != 0) {
                             DefaultMutableTreeNode matchEntry = new DefaultMutableTreeNode(
                                     "<html><font color='blue'>" + filePath + "</font></html>");
                             for (String match : matches) {
                                 matchEntry.add(new DefaultMutableTreeNode(match));
                             }
                             treeNode.add(matchEntry);
                         }

                     }
                     
                     if (treeNode.getChildCount() == 0) {
                         treeNode.setUserObject("<html><font color='red'>No Results Found</font></html>");
                     }
                                          
                     view.setResults(treeNode);          
            }
            
        };
        
    }
    
    public MouseListener getAddToPathListener() {
        return addToPathListener;
    }
    
    public MouseListener getSearchListener() {
        return doSearchListener;
    }
    
    private static List<String> getElementMatches(String element, File jarFile) {
        JarFile jar;
        List<String> entriesFound = new ArrayList<String>();
        
        try {
            jar = new JarFile(jarFile);
        } catch (IOException ex) {
            ex.printStackTrace();
            return entriesFound;
        }
        
        Enumeration<JarEntry> enu = jar.entries();                
        
        while (enu.hasMoreElements()) {
            JarEntry jarEntry = enu.nextElement();
            String name = jarEntry.getName();            
            int startIndex = name.toLowerCase().indexOf(element.toLowerCase());
            
            if (startIndex > -1) {
                
                StringBuilder sb = new StringBuilder();
                sb.append("<html>");
                
                if (startIndex > 0) {
                    sb.append(name.substring(0, startIndex));
                }
                
                int endIndex = startIndex + element.length();
                
                sb.append("<font color='green'><b><i>");
                sb.append(name.substring(startIndex, endIndex));
                sb.append("</b></i></font>");                                
                
                if (endIndex < name.length() - 1) {
                    sb.append(name.substring(endIndex));
                }
                
                sb.append("</html>");
                
                entriesFound.add(sb.toString());
                
            }
        }
        
        System.out.println("******** entriesFound = " + entriesFound);
        
        return entriesFound;
    }    
    
    private static String replaceDotsBySlashes(String toReplace) {                    
        
        if (!toReplace.contains(".")) {
            return toReplace;
        }
        
        String[] tokens = toReplace.split("\\.");
        
        StringBuilder sb = new StringBuilder(toReplace.length());
        
        for (String token : tokens) {
            sb.append(token).append("/");
        }
        
        sb.setLength(sb.length() - 1);
        return sb.toString();
        
    }
    
}
